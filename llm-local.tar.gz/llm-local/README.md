# LLM Local Lab

Run any Ollama model locally on your machine with a full chat UI, switchable between GPU and CPU with a single command.

**Stack:** [Ollama](https://ollama.com) (inference) + [Open WebUI](https://github.com/open-webui/open-webui) (chat interface)

---

## Prerequisites

### Always required
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) or Docker Engine + Compose v2

### For GPU mode (RTX 2070)
1. Install [NVIDIA drivers](https://www.nvidia.com/download/index.aspx) for your GPU
2. Install [NVIDIA Container Toolkit](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/install-guide.html):
   ```bash
   # Ubuntu/Debian
   curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
   curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
     sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
     sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
   sudo apt-get update && sudo apt-get install -y nvidia-container-toolkit
   sudo nvidia-ctk runtime configure --runtime=docker
   sudo systemctl restart docker
   ```

---

## Quick Start

```bash
# 1. Clone / copy this project
cd llm-local

# 2. Create your config (edit .env if needed)
cp .env.example .env

# 3a. Start with GPU  (RTX 2070)
make gpu

# 3b. Start with CPU  (Ryzen 5 1600)
make cpu

# 4. Open the chat UI
open http://localhost:3000
```

The first run will pull the default model (`qwen3:2b` unless you changed `DEFAULT_MODEL` in `.env`). This takes a few minutes depending on your internet connection.

---

## Switching Modes

```bash
# Stop current stack
make stop

# Restart in the other mode
make gpu   # or: make cpu
```

---

## Model Management

```bash
# Pull any model from https://ollama.com/library
make pull MODEL=mistral:7b-q4_0
make pull MODEL=minicpm5:1b
make pull MODEL=codellama:7b
make pull MODEL=llama3.2:3b

# List downloaded models
make models

# Remove a model
make rm-model MODEL=mistral:7b-q4_0

# Quick terminal chat (no WebUI)
make chat MODEL=qwen3:2b
```

---

## Recommended Models for Your Hardware

| Model | Size (Q4) | GPU | CPU | Best for |
|-------|-----------|-----|-----|----------|
| `minicpm5:1b` | ~0.6 GB | ✅ fast | ✅ fast | Edge testing, quick tasks |
| `qwen3:2b` | ~1.5 GB | ✅ fast | ✅ ok | General use, reasoning |
| `llama3.2:3b` | ~2.0 GB | ✅ fast | ⚠️ slow | General purpose |
| `mistral:7b-q4_0` | ~4.1 GB | ✅ good | ❌ very slow | Best GPU quality |
| `codellama:7b` | ~4.1 GB | ✅ good | ❌ very slow | Code tasks |
| `qwen3:8b` | ~5.2 GB | ⚠️ tight | ❌ | Best reasoning (GPU only) |

> **RTX 2070** has 8 GB VRAM — 7B Q4 models fit comfortably.  
> **Ryzen 5 1600** — stick to 1B–3B models for usable speed.

---

## All Commands

```
make gpu            Start with GPU
make cpu            Start with CPU
make stop           Stop all containers (keep data)
make clean          Stop + delete all volumes (⚠ removes model cache)
make pull MODEL=…   Pull a model
make models         List downloaded models
make rm-model MODEL=… Remove a model
make logs           Follow all logs
make logs-ollama    Follow Ollama logs only
make status         Container status + GPU memory
make chat MODEL=…   Terminal chat (no WebUI)
make help           Show this help
```

---

## Project Structure

```
llm-local/
├── docker-compose.yml        # Base services (Ollama + WebUI)
├── docker-compose.gpu.yml    # GPU override
├── docker-compose.cpu.yml    # CPU override
├── .env.example              # All config options with comments
├── .env                      # Your local config (gitignored)
└── Makefile                  # All commands
```

---

## Changing the Default Model

Edit `.env`:
```env
DEFAULT_MODEL=mistral:7b-q4_0
```

Then restart:
```bash
make stop && make gpu
```

The `model-init` service will pull the new model automatically on startup.
